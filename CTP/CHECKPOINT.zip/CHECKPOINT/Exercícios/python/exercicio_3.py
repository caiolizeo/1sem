dolar=float(input("informe a cotação do dólar: "))
real=float(input("informe quantos reais você possui: "))

conversao=real/dolar


print("Você possui ",round(conversao, 2)," dólares")