altura=float(input("Digite a altura: "))
raio=float(input("Digite o raio: "))

volume=3.14*(raio*raio)*altura

print("O volume cúbivo da lata é ",round(volume,2))