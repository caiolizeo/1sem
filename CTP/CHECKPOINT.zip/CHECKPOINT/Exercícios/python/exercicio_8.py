salario=float(input("Digite o salário: "))
despesas=float(input("Digite suas despesas: "))

resultado=1000000/((salario-despesas)*12)

print(round(resultado), " anos para se tornar milionário")