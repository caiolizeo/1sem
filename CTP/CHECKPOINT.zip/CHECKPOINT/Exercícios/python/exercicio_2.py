numero_1=int(input("Informe o primeiro valor: "))
numero_2=int(input("Informe o segundo valor: "))
numero_3=int(input("informe o terceiro valor: "))
numero_4=int(input("informe o quarto valor: "))

multiplicacao=numero_1*numero_3
soma=numero_2+numero_4

print("O resultado da multiplicação é: ",multiplicacao)
print("O resultado da soma é: ",soma)