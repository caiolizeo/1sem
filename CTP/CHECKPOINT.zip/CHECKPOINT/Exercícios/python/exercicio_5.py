celsius=float(input("Temperatura em graus Célsius: "))
fahrenheit=(celsius*1.8)+32

print("Temperatura em Fahrenheit: ",round(fahrenheit, 2))
