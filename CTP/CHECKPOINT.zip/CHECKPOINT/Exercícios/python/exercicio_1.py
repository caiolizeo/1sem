numero_1=int(input("Digite o primeiro número: "))
numero_2=int(input("Digite o segundo número: "))
numero_3=int(input("Digite o terceiro número: "))

soma = numero_1+numero_2+numero_3
quadrado = soma*soma

print("O quadrado das somas é: ", quadrado)